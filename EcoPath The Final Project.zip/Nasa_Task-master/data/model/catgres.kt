package com.example.mynasa.data.model

data class catgres( val number :Int ,val name : String , val decreption  : String , val image : Int  )
